
class cbma2x2_accel : public csensor_module
{
public:

	cbma2x2_accel();
	virtual ~cbma2x2_accel();

	const char *name(void);
	int version(void);
	int id(void);

	bool is_data_ready(bool wait=false);

	long value(const char *port);
	long value(int id);

	bool update_name(char *name);
	bool update_version(int ver);
	bool update_id(int id);

	int port_count(void);
	const char *port(int idx);

	bool need_polling(void);
	long polling_interval(void);
	bool update_polling_interval(unsigned long val);
	int get_sensor_type(void);
	long set_cmd(int type , int property , long input_value);
	int get_property(unsigned int property_level , void *property_data);
	int get_struct_value(unsigned int struct_type , void *struct_values);	

	bool calibration(int iteration);
	
	int check_hw_node(void);
	
	bool start(void);
	bool stop(void);

	void reset(void);	
	
private:

	static const char *m_port[];

	char *m_name;
	long m_id;
	long m_version;
	unsigned long m_polling_interval;

	int m_x;
	int m_y;
	int m_z;

	int m_offset_x;
	int m_offset_y;
	int m_offset_z;
	int m_calibration_flag;

	unsigned long long m_fired_time;

	bool update_value(void);

	int m_client;
	int m_sensor_type;
	char *m_resource;
	int m_accel_file_handle;
};

