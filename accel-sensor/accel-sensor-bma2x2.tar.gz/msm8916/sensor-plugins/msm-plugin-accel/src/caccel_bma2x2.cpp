#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <string.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <dirent.h>
#include <sys/poll.h>

#include <common.h>
#include <cobject_type.h>
#include <cmutex.h>
#include <clist.h>
#include <cmodule.h>
#include <cpacket.h>
#include <csync.h>
#include <cworker.h>
#include <csock.h>
#include <sf_common.h>

#include <csensor_module.h>

#include <caccel_bma2x2.h>
#include <sys/ioctl.h>
#include <stdint.h>
#include <errno.h>
#include <sys/cdefs.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <poll.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/select.h>
#include <linux/input.h>

#define SENSOR_NAME "bma2x2_accel"
#define SENSOR_CHIP_NAME "bma2x2"
#define SENSOR_CHIP_VENDOR "bosch"
#define SYSPATH	"/sys/class/sensors/bma2x2-accel"
#define INPUTPATH "/sys/class/input"
#define POLL_INTERVAL_MIN_MS (1)
#define SYSFS_MAXLEN (20)
#define ENABLE "enable"
#define POLLDELAY "poll_delay"
#define GRAVITY_EARTH           (9.80665f)
#define ACCEL_CONVERT           ((GRAVITY_EARTH) / 1024)
#define CONVERT_ACCEL_X         ACCEL_CONVERT
#define CONVERT_ACCEL_Y         ACCEL_CONVERT
#define CONVERT_ACCEL_Z         ACCEL_CONVERT

#define EVENT_TYPE_ACCEL_X      ABS_X
#define EVENT_TYPE_ACCEL_Y      ABS_Y
#define EVENT_TYPE_ACCEL_Z      ABS_Z

enum accelerometer_property_id {
	ACCELEROMETER_PROPERTY_UNKNOWN = 0,
	ACCELEROMETER_PROPERTY_SET_CALIBRATION,
	ACCELEROMETER_PROPERTY_CHECK_CALIBRATION_STATUS,
	ACCELEROMETER_PROPERTY_SET_WAKEUP,
	ACCELEROMETER_PROPERTY_CHECK_WAKEUP_STATUS,
	ACCELEROMETER_PROPERTY_CHECK_WAKEUP_SUPPORTED,
};


#ifndef strlcpy
#define strlcpy(x,y,z) strcpy(x, y)
#endif


struct bma2x2_acc {
	int16_t x;
	int16_t y;
	int16_t z;
};

const char *cbma2x2_accel::m_port[] = {"x", "y", "z",};

cbma2x2_accel::cbma2x2_accel()
: m_id(0x00000222)
, m_version(1)
, m_polling_interval(100000)
, m_x(-1)
, m_y(-1)
, m_z(-1)
, m_fired_time(0)
, m_client(0)
, m_sensor_type(ID_ACCEL)
{
	m_name = strdup(SENSOR_NAME);	
}

cbma2x2_accel::~cbma2x2_accel()
{
	free(m_name);
}

const char *cbma2x2_accel::name(void)
{
	return m_name;
}

int cbma2x2_accel::version(void)
{
	return m_version;
}

int cbma2x2_accel::id(void)
{
	return m_version;
}

int enable(int en) {
	int flags = en ? 1 : 0;
	char input_sysfs_path[PATH_MAX]={0};
	int fd;

	sprintf(input_sysfs_path, "%s/%s", SYSPATH, ENABLE);
	fd = open(input_sysfs_path, O_RDWR);
	if (fd >= 0) {
		char buf[2];
		int err;
		buf[1] = 0;
		if (flags) {
			buf[0] = '1';
		} else {
			buf[0] = '0';
		}
		err = write(fd, buf, sizeof(buf));
		close(fd);
		return 0;
	}
	ERR("failed to open %s", input_sysfs_path);
	return -1;
}

int poll_delay(int delayms) {
	char input_sysfs_path[PATH_MAX]={0};
	int fd;

	sprintf(input_sysfs_path, "%s/%s", SYSPATH, POLLDELAY);
	fd = open(input_sysfs_path, O_RDWR);
	if (fd >= 0) {
		char buf[32]={0};
		int err;
		
		sprintf(buf, "%d", delayms);
		err = write(fd, buf, strlen(buf)+1);
		close(fd);
		return 0;
	}
	ERR("failed to open %s", input_sysfs_path);
	return -1;
}

static int get_node(char *buf, char *path) {
	char * fret;
	int len = 0;
	FILE * fd;

	if (NULL == buf || NULL == path)
		return -1;

	fd = fopen(path, "r");
	if (NULL == fd)
		return -1;

	fret = fgets(buf,SYSFS_MAXLEN,fd);
	if (NULL == fret) {
		fclose(fd);
		return -1;
	}

	len = strlen(buf);

	if (buf[len - 1] == '\n')
		buf[len - 1] = '\0';

	fclose(fd);
	return 0;
}


int get_event_handle(void )
{
	int fd = -1;
	int err = -1;
	const char *dirname = INPUTPATH;
	char devname[PATH_MAX]={0};
	char *filename;
	char *nodename;
	DIR *dir;
	struct dirent *de;
	char tempname[SYSFS_MAXLEN];
	char eventpath[PATH_MAX]={0};

	dir = opendir(dirname);
	if(dir == NULL) {
		return -1;
	}
	strlcpy(devname, dirname, PATH_MAX - SYSFS_MAXLEN * 2 - 2);
	filename = devname + strlen(devname);
	*filename++ = '/';

	while((de = readdir(dir))) {
		if(de->d_name[0] == '.' &&
			(de->d_name[1] == '\0' ||
				(de->d_name[1] == '.' && de->d_name[2] == '\0')))
			continue;

		strlcpy(filename, de->d_name, SYSFS_MAXLEN);
		nodename = filename + strlen(de->d_name);
		*nodename++ = '/';
		
		if( strstr(de->d_name, "event") >= 0)
		{
			strlcpy(nodename, "device/name", SYSFS_MAXLEN);
			nodename = devname;
	
			err = get_node(tempname, nodename);
			if(err >= 0)
			{
				if( !strcmp(tempname, "accelerometer"))
				{
					nodename = filename + strlen(de->d_name);
			                *nodename++ = '/';
					strlcpy(nodename, "device/enable", SYSFS_MAXLEN);
		                        nodename = devname;

		                        err = get_node(tempname, nodename);
                        		if((err >= 0) && !strcmp(tempname,"1"))
					{
						snprintf(eventpath, PATH_MAX, "/dev/input/%s", de->d_name);
						break;
					}
				}
			}
		}
	}
        closedir(dir);

	if( strlen(eventpath) )
	{
		fd = open(eventpath, O_RDONLY);
	}

	return fd;
}



/*****************************************
  read sensor data from kernel
  can use i2c, ioctrl, fopen and fread
 ****************************************/
bool cbma2x2_accel::update_value(void)
{
	int x = 0;
	int y = 0;
	int z = 0;	
	struct bma2x2_acc acc_data;
	struct input_event events[6];

	if(m_accel_file_handle >= 0)
	{
		
		const ssize_t nread = read(m_accel_file_handle, events, 6 * sizeof(input_event));
		if (nread>0 && ( nread % sizeof(input_event) == 0)) {
			for(int i = 0; i < nread/sizeof(input_event); i++ )
			{
				input_event const* event = &events[i];
				int type = event->type;
				if (type == EV_ABS) {
					float value = event->value;
					if (event->code == EVENT_TYPE_ACCEL_X) {
						x = value;
					} else if (event->code == EVENT_TYPE_ACCEL_Y) {
						y = value;
					} else if (event->code == EVENT_TYPE_ACCEL_Z) {
						z = value;
					}
				} else if (type == EV_SYN) {
				
				}
			}
		}
	}
	csensor_module::lock();	

	m_x = x * CONVERT_ACCEL_X;
	m_y = y * CONVERT_ACCEL_Y;
	m_z = z * CONVERT_ACCEL_Z;

	csensor_module::unlock();

	DBG("Update done raw : %d, %d, %d , out_data : %d, %d, %d\n", x,y,z,m_x, m_y, m_z);
	return true;
}

bool cbma2x2_accel::is_data_ready(bool wait)
{
	bool ret = false;

	DBG("Sensor, invoked\n");

	if(wait)
	{
		unsigned long long cur_time;
		unsigned long elapsed_time;
		struct timeval sv;
		gettimeofday(&sv, NULL);
		cur_time = MICROSECONDS(sv);

		elapsed_time = (unsigned long)(cur_time - m_fired_time);

		if (elapsed_time < m_polling_interval) {
			usleep(m_polling_interval - elapsed_time);
			csensor_module::lock();
			m_fired_time = cur_time + (m_polling_interval-elapsed_time);
			csensor_module::unlock();
			ret = update_value();
		}
		else
			csensor_module::lock();
			m_fired_time = cur_time;
			csensor_module::unlock();
			return true;
	} else {
		DBG("update_value directly");
		ret = update_value();
	}


	return ret;
}

long cbma2x2_accel::value(const char *port)
{

	if (!strcasecmp(port, "x")) {
		return m_x;
	} else if (!strcasecmp(port, "y")) {
		return m_y;
	} else if (!strcasecmp(port, "z")) {
		return m_z;
	}

	return -1;
}

long cbma2x2_accel::value(int id)
{

	if (id == 0) {
		return m_x;
	} else if (id == 1) {
		return m_y;
	} else if (id == 2) {
		return m_z;
	}

	return -1;
}

void cbma2x2_accel::reset(void)
{
	return;
}

bool cbma2x2_accel::update_name(char *name)
{
	char *new_name;
	new_name = strdup(name);
	if (!new_name) {
		DBG("No memory\n");
		return false;
	}

	free(m_name);
	m_name = new_name;
	return true;
}

bool cbma2x2_accel::update_version(int version)
{
	m_version = version;
	return true;
}

bool cbma2x2_accel::update_id(int id)
{
	m_id = id;
	return true;
}

int cbma2x2_accel::port_count(void)
{
	return 3;
}

const char *cbma2x2_accel::port(int idx)
{
	if (idx >= (int)(sizeof(m_port)/sizeof(const char*))) {
		return NULL;
	}

	return m_port[idx];
}

bool cbma2x2_accel::need_polling(void)
{
	return m_polling_interval != 0;
}

long cbma2x2_accel::polling_interval(void)
{
	return (unsigned long long)m_polling_interval /1000llu ;
}

bool cbma2x2_accel::update_polling_interval(unsigned long val)
{
	if(val < 1)
	{
		ERR("invaild interval value");
		return false;
	}

	DBG("Update polling interval %lu\n", val);
	int64_t curr_delay_ns = val * 1000000;
	csensor_module::lock();
	m_polling_interval = (unsigned long long)val * 1000llu;
	csensor_module::unlock();

	poll_delay(val);

	return true;
}

bool cbma2x2_accel::start(void)
{
	int64_t curr_delay_ms = 200;
	int sensor_enable = 1;

	m_client ++;

	if (m_client > 1) {
		return true;
	}

	poll_delay(curr_delay_ms);
		
	enable(sensor_enable);

	m_accel_file_handle = get_event_handle();

	return true;
}

bool cbma2x2_accel::stop(void)
{

	int sensor_enable = 0;

	m_client --;
	if (m_client > 0) {
		DBG("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Stopping\n");
		return true;
	}

	enable(false);

	close(m_accel_file_handle);

	return true;
}

int cbma2x2_accel::get_sensor_type(void)
{
	return m_sensor_type;
}

long cbma2x2_accel::set_cmd(int type , int property , long input_value)
{
        long value = -1;
        struct pollfd Events;
        int retval;
        unsigned char buff = 0;
        FILE *fp;

        if ( type == m_sensor_type) {
                switch (property) {
                        case ACCELEROMETER_PROPERTY_SET_CALIBRATION :
                        default :
                                ERR("Invalid property_cmd\n");
                                break;
                }
        }
        else {
                ERR("Invalid sensor_type\n");
        }

        return value;

}


/*************************************
  sensor property 
*************************************/
int cbma2x2_accel::get_property(unsigned int property_level , void *property_data)
{
	if ( (property_level & 0xFFFF) == 1 ) {
		base_property_struct *return_property;
		return_property = (base_property_struct *)property_data;
		return_property->sensor_unit_idx = IDX_UNIT_METRE_PER_SECOND_SQUARED;
		return_property->sensor_min_range = -156.8;
		return_property->sensor_max_range = 156.8;
		snprintf(return_property->sensor_name,   sizeof(return_property->sensor_name),   SENSOR_CHIP_NAME  );
		snprintf(return_property->sensor_vendor, sizeof(return_property->sensor_vendor), SENSOR_CHIP_VENDOR);
		return_property->sensor_resolution = 0.156;
		return 0;

	} else {
		ERR("Doesnot support property_level : %d\n",property_level);
		return -1;
	}

	return -1;
}

int cbma2x2_accel::get_struct_value(unsigned int struct_type , void *struct_values)
{
	if ( (struct_type & 0xFFFF) == 0x0001) {
		base_data_struct *return_struct_value = NULL;
		return_struct_value = (base_data_struct *)struct_values;
		if ( return_struct_value ) {
			return_struct_value->data_accuracy = 2;
			return_struct_value->data_unit_idx = IDX_UNIT_VENDOR_UNIT;
			return_struct_value->time_stamp = m_fired_time ;
			return_struct_value->values_num = 3;
			return_struct_value->values[0] = m_x;
			return_struct_value->values[1] = m_y;
			return_struct_value->values[2] = m_z;

			return 0;
		} else {
			ERR("return struct_value point error\n");
		}

	} else {
		ERR("Does not support type , struct_type : %d \n",struct_type);		
	} 
	return -1;
}

cmodule *module_init(void *win, void *egl)
{
	cbma2x2_accel *sample;

	try {
		sample = new cbma2x2_accel();
	} catch (int ErrNo) {
		ERR("cbma2x2_accel class create fail , errno : %d , errstr : %s\n",ErrNo, strerror(ErrNo));
		return NULL;
	}

	return (cmodule*)sample;
}

void module_exit(cmodule *inst)
{
	cbma2x2_accel *sample = (cbma2x2_accel*)inst;
	delete sample;
}

